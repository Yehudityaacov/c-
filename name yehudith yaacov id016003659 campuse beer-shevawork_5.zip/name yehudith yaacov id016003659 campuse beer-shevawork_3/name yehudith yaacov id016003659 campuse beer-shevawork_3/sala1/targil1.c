//#define _CRT_SECURE_NO_WARNINGS
//#include<stdio.h>
//#include<conio.h>
//#include <stdlib.h>
//#include <string.h>
//#include <ctype.h>
//
//int input(int *num[], int size)//function pointer for array of numbers
//{
//	static int	i = 0, number = 0;
//	if (size == 0)//the end condition for the recursive
//		return 0;
//	else
//	{
//		printf("Enter an positiv number\n");
//		scanf("%d", &number);
//		num[i] = number;
//		i++;
//		return input(num, size - 1);/*The recursive call. */
//	}
//}
///** thisfunction halps and finds how many digits a given num includes**/
//int index = 0;                  /** global variable **/
//int sifra(int num)//
//{
//
//	if (num > 9)
//	{
//		sifra(num / 10);
//	}
//	else
//		index = 0;
//
//	index++;
//	return index;
//}
//int long_num(int *num, int size)//the progrem will find  how many num includes tree digit.
//{
//	static int counter = 0;
//	if (size == 0)
//		return 0;
//	if ((sifra(*num)) == 3)
//		return long_num(num+1 , size - 1) + 1;/*The recursive call. */
//	return long_num(num+1, size - 1);
//}
//
//int Is_Prime(int num, int i)
//{
//	if (num%i == 0)
//	{
//		return 0;
//	}
//	if (i <=num && i==2)
//	{
//		return 1;
//	}
//	return Is_Prime(num, i-1);/*The recursive call. */
//}
//int camut_Prime(int *num, int size)
//{
//	int multyplay = (*num) / 2;
//	if (size == 0)
//		return 0;
//	if (Is_Prime(*num, multyplay) == 1)
//		return camut_Prime(num + 1, size - 1) + 1;
//	return camut_Prime(num + 1, size - 1);
//}
///* ==========================/* MAIN PROGRAM /*===========================*/
//int main()
//{
//
//	int size = 0, *arr = NULL, res = 0, digit = 0, counter = 0, temp = 0;
//	int i = 0, restart = 0, k = 0;
//	printf("enter the size of number you whant to enter.\n");
//	scanf("%d", &size);
//	arr = (int*)malloc(size * sizeof(int));
//	if (!arr)
//	{
//		printf("ERROR !out of memory\n");
//		exit(1);
//	}
//	input(arr, size);
//	int multiplay = *(arr) / 2;
//	int *ptr;
//	do
//	{
//		printf("please choose one of the following option ;\n");
//		printf("for finding the number with the length of tree digit press 1;\n");
//		printf("for cheking if number is prime number press 2;\n");
//		printf(" for finding the length of the primwe number press 3;\n");
//		printf("for exit press 0! ;\n");
//		scanf("%d", &k);
//		system("cls");
//		_flushall();
//		switch (k)
//		{
//		case 1:
//
//			long_num(arr, size);
//			printf("amount of number  that countin 3 digit is :%d\n", long_num(arr, size));
//			printf("\n=======================================================\n");
//			break;
//
//		case 2:
//
//			for (ptr = arr; ptr <= &arr[size - 1]; ptr++)
//			{
//				Is_Prime((*arr), multiplay);
//				printf(" %d :%d\n", *ptr, Is_Prime(*ptr, multiplay));
//			}
//			printf("\n=======================================================\n");
//			break;
//		case 3:
//			camut_Prime(arr, size);
//			printf("amount of number  thath area prime number are :%d\n", camut_Prime(arr, size));
//			printf("\n=======================================================\n");
//			break;
//
//		}
//		printf("press any number to contcontinue:\n");
//	} while (k != 0);
//	printf(" BYE BYE !\n");
//	free(input);
//	return 0;
//}
