//#define _CRT_SECURE_NO_WARNINGS
//#include<stdio.h>
//#include<conio.h>
//#include <stdlib.h>
//#include <string.h>
//#include <ctype.h>
//#define SIZE 21
// typedef struct
//{
//	char model[SIZE];
//	char Mamufactaturer[SIZE];
//	int memory;
//	int create;
//}laptop;
//int get_data(laptop **p)
//{
//	laptop sp;
//	int size = 0;
//	FILE*fsp;
//	char*fn = "data.txt";
//	fsp = fopen(fn, "r");
//	if (!fsp)
//	{
//		printf("Can't open file\n");
//		exit(0);
//	}
// 	while (fscanf(fsp, "%s\n\r %s\n\r %d\n\r %d\n\n", sp.model, sp.Mamufactaturer, &sp. memory, &sp.create) != EOF)//creating adinamic memory for gatting data from the file.
// 	{
// 
// 		if (size == 0)
// 		{
// 			*p = (laptop*)malloc(1 * sizeof(laptop));
// 			if (!(*p)){
// 				printf("out of memory.\n");
// 				exit(1);
// 			}
// 			strcpy((*p)[size].model, sp.model);
//			strcpy((*p)[size].Mamufactaturer, sp.Mamufactaturer);
// 			(*p)[size].memory = sp.memory;
// 			(*p)[size]. create= sp.create;
// 			size = 1;
// 		}
//		else
//		{
//
//			*p = (laptop*)realloc((*p), sizeof(laptop)*(size + 1));
//			if (!(*p)){
//				printf("out of memory.\n");
//				exit(1);
//			}
//			strcpy((*p)[size].model, sp.model);
//			strcpy((*p)[size].Mamufactaturer, sp.Mamufactaturer);
//			(*p)[size].memory = sp.memory;
//			(*p)[size].create = sp.create;
//			size++;
//		}
// 	}
// 	fclose(fsp);
// 	return size;
// }
//void print_laptopData(laptop*C, int size)
//{
//	int i, max = 0,tamp=0;
//
//	printf("list of the computer with the lergest memory and created after 2014 is:\n\r");
//	for (i = 0; i < size; i++)
//	{
//		if ((C[i].create) > 2014)
//		{
//			printf("Computer Model: %s\n\rManufacturer: %s\n\rMemory: %d\n\rCreat in year: %d \n\r", C[i].model, C[i].Mamufactaturer, C[i].memory, C[i].create);
//		}
//	}
//	i = 0;
//	max = C[i].memory;
//	for (i = 0; i < size; i++)
//	{
//		if (max > C[i - 1].memory)
//		{
//			tamp = max;
//			max = C[i].memory;
//		}
//		else if (C[i].memory < C[i-1].memory)
//		{
//			tamp = max;
//			max = C[i - 1].memory;
//
//		}
//		
//	}
//	printf("the laptop with the largest memory; %d", max);
//} 
// int main()
// {
// 	laptop *p=NULL;
// 	int size;
// 	size =get_data(&p);
// 	print_leptopData(p,size);
// 	printf("\n============================================================\n");
// 	getchar();
// 	return 0;
// }