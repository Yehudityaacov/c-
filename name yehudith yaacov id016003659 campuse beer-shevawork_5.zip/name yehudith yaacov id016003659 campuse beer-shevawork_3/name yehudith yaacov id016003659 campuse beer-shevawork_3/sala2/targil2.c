//#define _CRT_SECURE_NO_WARNINGS
//#include<stdio.h>
//#include<conio.h>
//#include <stdlib.h>
//#include <string.h>
//#include <ctype.h>
//#define SIZE 81
//int equivalent(char*e, char*q)//the function chack if 1 string is sub string of the second string
//{
//	static int counter = 0;
//	if ((*q == '\0') || (*q == '\0'))
//		return counter;
//	if ((*e == *q))
//	{
//		counter = 1;
//		return equivalent(e + 1, q + 1);
//	}
//	else{
//		counter = 0;
//		return equivalent(e + 1, q);
//	}
//}
///******************************************************************/
//int counter = 0; /** global variable **/
//int big_letter(char* str)//counting the latin big letter in the string
//{
//	if (*str == '\0')
//		return counter;
//	else
//	{
//		if (*str >= 'A'&&*str <= 'Z')
//		{
//			counter++;
//			return big_letter(str+1)+1;
//		}
//		else
//			return 0;
//		
//	}
//}
///******************************************************************/
//int is_lattin(char*L)//chaking if the string contain a latin small letter
//{
//	static int size = 0;
//	if (*L == '\0')
//		return size;
//	else
//	{
//		if (*L >= 97 && *L <= 122)
//		{
//			size = 1;
//			return is_lattin(L + 1);
//		}
//		else
//			return 0; 
//		
//	}
//	
//}
///******************************************************************/
//int is_Big(char *C, char *C1)// chaking  which string  is longer OR equal
//{
//
//	if ((*C == '\0') && (*C1 == '\0'))
//		return 0;
//	else
//	{
//		if ((*C == '\0') && (*C1 != '\0'))
//			return 1;
//		if ((*C != '\0') && (*C1 == '\0'))
//			return 2;
//
//	}
//	is_Big(C+1, C1+1 );
//}
///******************************************************************/
//
//int is_num(char *K)//chaking if the all characters in the even cell are digit
//{ 
//	static int size = 0;
//	if (*K == '\0')
//		return size;
//	else
//	{
//		if (*K <= '9' && *K >= '0')
//		{
//			size = 1;
//			return is_num(K + 2);
//		}
//		else
//			return size;
//		
//	}
//}
///******************************************************************/
//int len_str(char *p)// chaking the length of a string
//{
//	static int counter = 0;
//	if (p[counter] == '\0')
//		return counter;
//	else
//		counter++;
//	len_str(p);
//	return counter;
//}
///********************************************************************************/
//int main()
//{
//	char arr[SIZE] , arr1[SIZE];
//	char option = 0;
//	int restart = 0;
//	
//	printf("please enter 2 string [maximom 80 words in evry string]\n");
//	_flushall();
//	scanf("%s %s", &arr, &arr1);
//		do
//		{
//			
//			printf("please choose one of the following option:\n");
//			printf("for chaking if which string of 2 strings is longer OR equal press A:\n");
//			printf("for chaking if 1 string contain a latin small letter press B:\n");
//			printf("for chaking the length of a string press C:\n");
//			printf("for counting the latin big letter in the string press D:\n");
//			printf("for chaking if the all characters in the even cell are digit press E:\n");
//			printf("for  chack if 1 string is sub string of the second string press F : \n");
//			printf("for exit press any G:\n");
//			_flushall();
//			scanf("%c", &option);
//			switch (option)
//			{
//			case 'A':
//				printf("%d\n", is_Big(arr, arr1));
//				break;
//
//			case 'B':
//				printf("%d\n", is_lattin(arr));
//				break;
//
//			case 'C':
//				printf("%d\n", len_str(arr));
//				break;
//			case 'D':
//				printf("%d\n", big_letter(arr));
//				
//				break;
//			case 'E':
//				printf("%d\n", is_num(arr));
//				break;
//			case 'F':
//				printf("%d\n", equivalent(arr, arr1));
//				break;
//			case 'G':
//			default:printf("good bye!.\n");
//				getchar();
//
//			}
//
//		} while (option!='G');
//	return 0;
//}
//
//
