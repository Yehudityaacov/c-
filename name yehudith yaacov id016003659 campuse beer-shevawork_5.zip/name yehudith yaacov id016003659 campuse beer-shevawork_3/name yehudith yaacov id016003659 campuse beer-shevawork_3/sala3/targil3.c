//#define _CRT_SECURE_NO_WARNINGS
//#include<stdio.h>
//#include<conio.h>
//#include <stdlib.h>
//#include <string.h>
//#include <ctype.h>
//#define SIZE 21
//typedef struct
//{
//	char name[SIZE];
//	char gender;
//	int age;
//	char d1[SIZE];
//	char d2[SIZE];
//	char d3[SIZE];
//	
//}clint;
//int get_data(clint **p)//opning a file 
//{
//	clint st;
//	char ls_name[SIZE];
//	int size = 0;
//	FILE*fst;
//	char*fn = "data1.txt";
//	fst = fopen(fn, "r");
//	if (!fst)
//	{
//		printf("Can't open file\n");
//		exit(0);
//	}
//	while (fscanf(fst, "%s %s %c %d %s %s %s", st.name, &ls_name , &st.gender, &st.age, st.d1, st.d2, st.d3) != EOF)//creating adinamic memory for gatting data from the file.
//	{
//		strcat(st.name, " ");//last name 
//		strcat(st.name, ls_name);
//		if (size == 0)
//		{
//			*p = (clint*)malloc(1 * sizeof(clint));
//			if (!(*p)){
//				printf("out of memory.\n");
//				exit(1);
//			}
//			strcpy((*p)[size].name, st.name);
//			(*p)[size].gender = st.gender;
//			(*p)[size].age = st.age;
//			strcpy((*p)[size].d1, st.d1);
//			strcpy((*p)[size].d2, st.d2);
//			strcpy((*p)[size].d3, st.d3);
//			size = 1;
//		}
//		else
//		{
//
//			*p = (clint*)realloc((*p), sizeof(clint)*(size + 1));
//			if (!(*p)){
//				printf("out of memory.\n");
//				exit(1);
//			}
//			strcpy((*p)[size].name, st.name);
//			(*p)[size].gender = st.gender;
//			(*p)[size].age = st.age;
//			strcpy((*p)[size].d1, st.d1);
//			strcpy((*p)[size].d2, st.d2);
//			strcpy((*p)[size].d3, st.d3);
//			size++;
//		}
//			
//		
//	}
//	fclose(fst);
//	return size;
//}
//void print_ClintData(clint*C, clint NewC, int size)//compring new clint database if ther is a match
//{
//	int i;
//	int flag = 0;
//	printf("list of match:\n\n");
//	for (i = 0; i < size; i++)
//	{
//
//		if (C[i].gender != NewC.gender)
//		{
//			if ((abs(C[i].age - NewC.age)) <= 10)
//			{
//				if (strcmp(C[i].d1, NewC.d1) == 0 || strcmp(C[i].d2, NewC.d2) == 0 || strcmp(C[i].d3, NewC.d3) == 0 || strcmp(C[i].d1, NewC.d2) == 0 || strcmp(C[i].d1, NewC.d3) == 0 || strcmp(C[i].d2, NewC.d3) == 0 || strcmp(C[i].d2, NewC.d1) == 0 || strcmp(C[i].d3, NewC.d1) == 0 || strcmp(C[i].d3, NewC.d2) == 0)
//				{
//					printf("Name: %s\n Gender: %c\n  Age: %d\n dicipline: \n %s \n %s \n %s \n ", C[i].name, C[i].gender, C[i].age, C[i].d1, C[i].d2, C[i].d3);
//					flag++;
//				}
//			}
//		}
//	}
//	if (flag == 0)
//		printf("sure we goth no mach!.\n");
//}
//void NewclintData(clint *NewC)// gating details of the new clint
//{
//	printf("Enter the name of the claint:");
//	_flushall();
//	gets(NewC->name);
//	printf("Enter the gender<m or f>:");
//	gets(&(NewC->gender));
//	_flushall();
//	printf("Enter age:");
//	scanf("%d", &(NewC->age));
//	printf("Enter the dicipline 1:");
//	scanf("%s", NewC->d1);
//	_flushall();
//	printf("Enter the dicipline 2:");
//	scanf("%s", NewC->d2);
//	printf("Enter the dicipline 3:");
//	scanf("%s", NewC->d3);
//}
//int main()
//{
//	clint *p=NULL;
//	clint NewC ;
//	int size;
//	size =get_data(&p);
//	NewclintData(&NewC);
//	print_ClintData(p, NewC,size);
//	printf("============================================================\n");
//	getchar();
//	/*free(p);*/
//	return 0;
//}